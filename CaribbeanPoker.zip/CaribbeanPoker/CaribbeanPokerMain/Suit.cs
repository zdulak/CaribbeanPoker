using System;

namespace CaribbeanPokerMain
{
    public enum Suit
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}