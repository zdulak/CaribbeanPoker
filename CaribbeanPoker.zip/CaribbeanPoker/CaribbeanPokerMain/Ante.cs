using System;

namespace CaribbeanPokerMain
{
    enum Ante
    {
        Ten = 10,
        Twenty = 20,
        Fifty = 50,
        Hundred = 100
    }
}