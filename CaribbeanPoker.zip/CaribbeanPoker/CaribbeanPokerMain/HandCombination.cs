namespace CaribbeanPokerMain
{
    public enum HandCombination
    {
        nothing = 1,
        pair,
        two_pair,
        triplets,
        straight,
        flush,
        full,
        quads,
        straight_flush,
        royal_flush
    }
}
